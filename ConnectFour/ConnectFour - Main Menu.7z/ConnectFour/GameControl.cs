﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConnectFour {
    public partial class GameControl : UserControl {
        private static readonly GameControl _instance = new GameControl();

        public static GameControl instance {
            get {
                _instance.game.Reset();
                _instance.mainMenuButton.Visible = false;
                _instance.playAgainButton.Visible = false;
                return _instance;
            }
        }

        private readonly Game game;

        protected GameControl() {
            InitializeComponent();

            game = new Game(7, 6);

            gamePanel.Invalidate();
            currentTurnPanel.Invalidate();
        }

        private void gamePanel_Paint(object sender, PaintEventArgs e) {
            if (!(sender is Panel panel))
                return;

            if (game == null)
                return;

            game.Draw(e.Graphics, panel.Size);
        }

        private void currentTurnPanel_Paint(object sender, PaintEventArgs e) {
            if (!(sender is Panel panel))
                return;

            if (game == null)
                return;

            game.DrawCurrentPlayer(e.Graphics, panel);
        }

        private void gamePanel_MouseClick(object sender, MouseEventArgs e) {
            if (!(sender is Panel))
                return;

            if (game == null)
                return;

            if (game.isGameOver)
                return;

            if (game.PlacePiece(e.Location)) {
                gamePanel.Invalidate();
                currentTurnPanel.Invalidate();

                if (game.isGameOver) {
                    playAgainButton.Visible = true;
                    mainMenuButton.Visible = true;
                }
            }
        }

        private void playAgainButton_Click(object sender, EventArgs e) {
            if (!(sender is Button button))
                return;

            if (game == null)
                return;

            game.Reset();
            gamePanel.Invalidate();
            currentTurnPanel.Invalidate();

            button.Visible = false;
            mainMenuButton.Visible = false;
        }

        private void mainMenuButton_Click(object sender, EventArgs e) {
            ConnectFour.instance.SetViewControl(MainMenu.instance);
        }
    }
}
