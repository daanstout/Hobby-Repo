﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConnectFour {
    public class Game {
        /// <summary>
        /// The different possible pieces
        /// </summary>
        enum Pieces {
            clear = 0x0,
            red = 0x1,
            yellow = 0x2
        }

        /// <summary>
        /// The size of a square, both width and height
        /// </summary>
        private const int SQUARE_SIZE = 60;
        /// <summary>
        /// The offset from the edge to where the hole begins
        /// </summary>
        private const int SQUARE_OFFSET = (int)(SQUARE_SIZE * 0.1);

        /// <summary>
        /// The brush to use for the field
        /// </summary>
        private readonly Brush fieldBrush = Brushes.Blue;
        /// <summary>
        /// The brush to use for the background
        /// </summary>
        private readonly Brush backgroundBrush = new SolidBrush(Color.FromArgb(70, 70, 70));

        /// <summary>
        /// The playing field
        /// </summary>
        private Pieces[,] field;
        /// <summary>
        /// The width of the playing field
        /// </summary>
        private readonly int width;
        /// <summary>
        /// The height of the playing field
        /// </summary>
        private readonly int height;

        /// <summary>
        /// Indicates whether the game is over
        /// </summary>
        public bool isGameOver { get; private set; } = false;
        /// <summary>
        /// The 4 x-positions of the winning pieces
        /// </summary>
        private int[] wonXpos;
        /// <summary>
        /// The 4 y-positions of the winning pieces
        /// </summary>
        private int[] wonYpos;

        /// <summary>
        /// The color of the current player
        /// </summary>
        private Pieces currentPlayer;
        /// <summary>
        /// The next player's color
        /// </summary>
        private Pieces nextPlayer => currentPlayer == Pieces.red ? Pieces.yellow : Pieces.red;

        /// <summary>
        /// An instance of the random class for random values
        /// </summary>
        private Random random;

        /// <summary>
        /// Instantiates a new game
        /// </summary>
        /// <param name="width">How many pieces can be placed in the horizontally</param>
        /// <param name="height">How many pieces can be placed vertically</param>
        public Game(int width, int height) {
            this.width = width;
            this.height = height;

            Reset();
        }

        /// <summary>
        /// Resets the playing field
        /// </summary>
        public void Reset() {
            field = new Pieces[width, height];
            wonXpos = new int[4] { -1, -1, -1, -1 };
            wonYpos = new int[4] { -1, -1, -1, -1 };
            isGameOver = false;

            random = new Random();

            currentPlayer = random.Next(0, 2) == 0 ? Pieces.red : Pieces.yellow;
        }

        /// <summary>
        /// Draws the playing board
        /// </summary>
        /// <param name="g">The instance of the graphics class</param>
        /// <param name="fieldSize">The size of the playing field in pixels</param>
        public void Draw(Graphics g, Size fieldSize) {
            if (g == null || field == null)
                return;

            g.FillRectangle(fieldBrush, new Rectangle(new Point(0, 0), fieldSize));

            Brush squareBrush;
            Point location;
            // The size of a square is equal to the square size, minus twice the offset, as the offset has to be removed on both sides.
            Size size = new Size(SQUARE_SIZE - (SQUARE_OFFSET * 2), SQUARE_SIZE - (SQUARE_OFFSET * 2));

            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    // The location is X square sizes + the offset, and the same for the Y
                    location = new Point {
                        X = x * SQUARE_SIZE + SQUARE_OFFSET,
                        Y = y * SQUARE_SIZE + SQUARE_OFFSET
                    };

                    squareBrush = field[x, y] switch
                    {
                        Pieces.red => Brushes.Red,
                        Pieces.yellow => Brushes.Yellow,
                        _ => backgroundBrush,
                    };

                    g.FillEllipse(squareBrush, new Rectangle(location, size));
                }
            }

            // If the game is over, draw dots on the winning pieces and connect them with a line
            if (isGameOver) {
                Size dotSize = new Size((int)(SQUARE_SIZE * 0.2f), (int)(SQUARE_SIZE * 0.2f));

                for (int i = 0; i < 4; i++) {
                    location = new Point {
                        X = wonXpos[i] * SQUARE_SIZE + (int)(SQUARE_SIZE * 0.4f),
                        Y = wonYpos[i] * SQUARE_SIZE + (int)(SQUARE_SIZE * 0.4f)
                    };

                    g.FillEllipse(Brushes.Black, new Rectangle(location, dotSize));
                }

                using Pen pen = new Pen(Color.Black, SQUARE_SIZE / 15.0f);

                for (int i = 0; i < 3; i++) {
                    location = new Point {
                        X = wonXpos[i] * SQUARE_SIZE + (int)(SQUARE_SIZE * 0.5f),
                        Y = wonYpos[i] * SQUARE_SIZE + (int)(SQUARE_SIZE * 0.5f)
                    };

                    Point location2 = new Point {
                        X = wonXpos[i + 1] * SQUARE_SIZE + (int)(SQUARE_SIZE * 0.5f),
                        Y = wonYpos[i + 1] * SQUARE_SIZE + (int)(SQUARE_SIZE * 0.5f)
                    };

                    g.DrawLine(pen, location, location2);
                }
            }
        }

        /// <summary>
        /// Draws the current player's turn to the panel
        /// </summary>
        /// <param name="g">The graphics instance to draw too</param>
        /// <param name="panel">The panel we draw in</param>
        public void DrawCurrentPlayer(Graphics g, Panel panel) {
            if (g == null || panel == null)
                return;

            string textToDraw;

            // Set the text depending on whether the game is over or not
            if (isGameOver)
                textToDraw = $"{(currentPlayer == Pieces.red ? "Red" : "Yellow")} has won!";
            else
                textToDraw = $"It is {(currentPlayer == Pieces.red ? "Red" : "Yellow")}'s turn";

            SizeF textSize = g.MeasureString(textToDraw, panel.Font);

            PointF location = new PointF {
                X = (panel.Width - textSize.Width) / 2,
                Y = (panel.Height - textSize.Height) / 2
            };

            Brush textColor = currentPlayer switch
            {
                Pieces.red => Brushes.Red,
                Pieces.yellow => Brushes.Yellow,
                _ => Brushes.White,
            };

            g.DrawString(textToDraw, panel.Font, textColor, location);
        }

        /// <summary>
        /// Attempts to place a piece on the board
        /// </summary>
        /// <param name="location">The location to place a piece. (Only the X-value is really relevant)</param>
        /// <returns>True if a piece was placed, false if a piece could not be placed</returns>
        public bool PlacePiece(Point location) {
            if (location.X < 0 || location.X >= width * SQUARE_SIZE ||
                location.Y < 0 || location.Y >= height * SQUARE_SIZE)
                return false;

            if (isGameOver)
                return true;

            // Get the column the piece was placed in
            // We don't have to check if it fits because the first if-statement makes sure we are not out of bounds
            int column = location.X / SQUARE_SIZE;
            int availableY = -1;

            // Look where we can place a piece
            for (int y = 0; y < height; y++) {
                if (field[column, y] == Pieces.clear)
                    availableY = y;
                else
                    break;
            }

            // If there are no available spaces in the column, we can't place a piece
            if (availableY == -1)
                return false;

            field[column, availableY] = currentPlayer;

            // Check whether there is a win for either player
            isGameOver = CheckForWin();

            // If a player won, we don't want to update the current player
            if (isGameOver)
                return true;

            currentPlayer = nextPlayer;

            return true;
        }

        /// <summary>
        /// Checks for a win, for all players
        /// </summary>
        /// <returns>True if ANY player has 4 connected pieces</returns>
        private bool CheckForWin() => CheckHorizontal() || CheckVertical() || CheckDiagonalLeft() || CheckDiagonalRight();

        /// <summary>
        /// Checks if there is a horizontal win
        /// </summary>
        /// <returns>True if ANY player has 4 horizontally-connected pieces</returns>
        private bool CheckHorizontal() {
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width - 3; x++) {
                    Pieces color = field[x, y];

                    if (color == Pieces.clear)
                        continue;

                    bool uninterrupted = true;
                    for (int length = 1; length < 4; length++)
                        if (field[x + length, y] != color)
                            uninterrupted = false;

                    if (uninterrupted) {
                        wonXpos = new int[4] { x, x + 1, x + 2, x + 3 };
                        wonYpos = new int[4] { y, y, y, y };
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Checks if there is a vertical win
        /// </summary>
        /// <returns>True if ANY player has 4 vertically-connected pieces</returns>
        private bool CheckVertical() {
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height - 3; y++) {
                    Pieces color = field[x, y];

                    if (color == Pieces.clear)
                        continue;

                    bool uninterrupted = true;
                    for (int length = 1; length < 4; length++)
                        if (field[x, y + length] != color)
                            uninterrupted = false;

                    if (uninterrupted) {
                        wonXpos = new int[4] { x, x, x, x };
                        wonYpos = new int[4] { y, y + 1, y + 2, y + 3 };

                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Checks if there is a diagonal win that goes from top-left to bottom-right
        /// </summary>
        /// <returns>True if ANY player has 4 diagonally-connected pieces</returns>
        private bool CheckDiagonalRight() {
            int x = 0, y = 0;
            // Loop through the three possible right-wards diagonals from the left most line
            for (; y < 3; y++) {
                // The 4-long line we look for has up to 3 starting positions, depending on the currentY we start at
                // To get that value, we take 3 (the max number of positions) and substract the current Y value
                for (int offset = 0; y + offset < 3; offset++) {
                    // The color of the top-left most piece we are looking at
                    Pieces currentColor = field[x + offset, y + offset];

                    // If the current color is clear (no piece present), we don't have to look
                    if (currentColor == Pieces.clear)
                        continue;

                    // Look if the four tiles have the same color
                    bool uninterrupted = true;
                    for (int length = 1; length < 4; length++)
                        if (field[x + offset + length, y + offset + length] != currentColor)
                            uninterrupted = false;

                    if (uninterrupted) {
                        wonXpos = new int[4] { x + offset, x + offset + 1, x + offset + 2, x + offset + 3 };
                        wonYpos = new int[4] { y + offset, y + offset + 1, y + offset + 2, y + offset + 3 };

                        return true;
                    }
                }
            }

            y = 0;
            x = 1;

            for (; x < 4; x++) {
                for (int offset = 0; x + offset < 4; offset++) {
                    Pieces currentColor = field[x + offset, y + offset];

                    if (currentColor == Pieces.clear)
                        continue;

                    bool uninterrupted = true;
                    for (int length = 1; length < 4; length++)
                        if (field[x + offset + length, y + offset + length] != currentColor)
                            uninterrupted = false;

                    if (uninterrupted) {
                        wonXpos = new int[4] { x + offset, x + offset + 1, x + offset + 2, x + offset + 3 };
                        wonYpos = new int[4] { y + offset, y + offset + 1, y + offset + 2, y + offset + 3 };

                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Checks if there is a diagonal win that goes from top-right to bottom-left
        /// </summary>
        /// <returns>True if ANY player has 4 diagonally-connected pieces</returns>
        private bool CheckDiagonalLeft() {
            int x = width - 1, y = 0;

            for (; y < 3; y++) {
                for (int offset = 0; y + offset < 3; offset++) {
                    Pieces currentColor = field[x - offset, y + offset];

                    if (currentColor == Pieces.clear)
                        continue;

                    bool uninterrupted = true;
                    for (int length = 1; length < 4; length++)
                        if (field[x - offset - length, y + offset + length] != currentColor)
                            uninterrupted = false;

                    if (uninterrupted) {
                        wonXpos = new int[4] { x - offset, x - offset - 1, x - offset - 2, x - offset - 3 };
                        wonYpos = new int[4] { y + offset, y + offset + 1, y + offset + 2, y + offset + 3 };

                        return true;
                    }
                }
            }

            y = 0;
            x = width - 2;

            for (; x > 2; x--) {
                for (int offset = 0; x - offset > 2; offset++) {
                    Pieces currentColor = field[x - offset, y + offset];

                    if (currentColor == Pieces.clear)
                        continue;

                    bool uninterrupted = true;
                    for (int length = 1; length < 4; length++)
                        if (field[x - offset - length, y + offset + length] != currentColor)
                            uninterrupted = false;

                    if (uninterrupted) {
                        wonXpos = new int[4] { x - offset, x - offset - 1, x - offset - 2, x - offset - 3 };
                        wonYpos = new int[4] { y + offset, y + offset + 1, y + offset + 2, y + offset + 3 };

                        return true;
                    }
                }
            }

            return false;
        }
    }
}
