﻿namespace ConnectFour {
    partial class MainMenu {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.playRegularButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // playRegularButton
            // 
            this.playRegularButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.playRegularButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playRegularButton.ForeColor = System.Drawing.Color.White;
            this.playRegularButton.Location = new System.Drawing.Point(160, 60);
            this.playRegularButton.Name = "playRegularButton";
            this.playRegularButton.Size = new System.Drawing.Size(100, 35);
            this.playRegularButton.TabIndex = 0;
            this.playRegularButton.Text = "Play!";
            this.playRegularButton.UseVisualStyleBackColor = true;
            this.playRegularButton.Click += new System.EventHandler(this.playRegularButton_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.Controls.Add(this.playRegularButton);
            this.Name = "MainMenu";
            this.Size = new System.Drawing.Size(420, 420);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button playRegularButton;
    }
}
