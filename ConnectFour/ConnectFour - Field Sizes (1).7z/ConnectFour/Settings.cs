﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectFour {
    public static class Settings {
        private static readonly Size[] fieldSizes = new Size[] { new Size(5, 4), new Size(7, 6), new Size(9, 8), new Size(11, 10) };

        private static int _currentFieldSizeIndex = 1;

        public static int currentFieldSizeIndex {
            get => _currentFieldSizeIndex;
            set {
                if (value < 0)
                    value = 0;
                else if (value >= fieldSizes.Length)
                    value = fieldSizes.Length - 1;
                _currentFieldSizeIndex = value;
            }
        }

        public static Size currentFieldSize => fieldSizes[_currentFieldSizeIndex];
    }
}
