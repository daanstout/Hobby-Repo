﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConnectFour {
    public partial class SettingsControl : UserControl {
        private static readonly SettingsControl _instance = new SettingsControl();

        public static SettingsControl instanced {
            get {
                return _instance;
            }
        }

        private SettingsControl() {
            InitializeComponent();
        }

        private void backButton_Click(object sender, EventArgs e) {
            ConnectFour.instance.SetViewControl(MainMenu.instance);
        }

        private void sizeSmallButton_Click(object sender, EventArgs e) {
            Settings.currentFieldSizeIndex = 0;
        }

        private void sizeNormalButton_Click(object sender, EventArgs e) {
            Settings.currentFieldSizeIndex = 1;
        }

        private void sizeLargeButton_Click(object sender, EventArgs e) {
            Settings.currentFieldSizeIndex = 2;
        }

        private void sizeExtraLargeButton_Click(object sender, EventArgs e) {
            Settings.currentFieldSizeIndex = 3;
        }
    }
}
